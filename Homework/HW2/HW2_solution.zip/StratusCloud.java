package weather;

public class StratusCloud extends Cloud
{
	public StratusCloud(float bottom, float top)
	{
		super(bottom, top);
	}
}
