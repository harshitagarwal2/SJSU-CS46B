package queens;

enum BoardEvaluation 
{
	ACCEPT, ABANDON, CONTINUE
}
