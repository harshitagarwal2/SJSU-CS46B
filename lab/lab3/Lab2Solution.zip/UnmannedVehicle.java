package transport;

public class UnmannedVehicle extends Vehicle
{
	UnmannedVehicle()
	{
		super(4);
	}
}
