package dna;

public class RecordFormatException extends Exception
{
	// Complete this.
	public RecordFormatException(String message)
	{
		super(message);
	}
}
