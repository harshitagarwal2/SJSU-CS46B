package weather;

public class CumulusCloud extends Cloud
{
	public CumulusCloud(float bottom, float top)
	{
		super(bottom, top);
	}
}
