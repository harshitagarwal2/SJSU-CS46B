package transport;

public class Vehicle 
{
	private int 		nWheels;
	
	
	Vehicle(int nWheels)
	{
		this.nWheels = nWheels;
	}
}
