package transport;

public class MarsRover extends UnmannedVehicle
{	
}
