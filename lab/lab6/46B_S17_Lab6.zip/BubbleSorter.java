package bubble;

public class BubbleSorter 
{
	private int[]		a;
	private long		nVisits;
	private long		nSwaps;
	
	
	public BubbleSorter(int[] a)
	{
		this.a = a; 
	}
	
	
	public void sort()
	{
		for (/* control the outer loop */)
		{
			for (/* control the outer loop */)
			{
				// Increment number of visits by 2.
				if (/* if 2 elements you're visiting need to be swapped */)
				{
					// Swap the elements and increment nSwaps.
				}
			}
		}
	}
	
	
	public String toString()
	{
		String s = nVisits + " visits, " + nSwaps + " swaps\n{";
		for (int n: a)
			s += " " + n;
		s += " }";
		return s;
	}
	
	
	public boolean isSorted()
	{
		/* Implement this */
	}
	
	
	public long getNVisits()
	{
		/* Implement this */
	}
	
	
	public long getNSwaps()
	{
		/* Implement this */
	}
	
	
	public int[] getArray()
	{
		return a;
	}
	
	
	public static void main(String[] args)
	{
		int[] a = BubbleSortTestCaseMaker.getTiny();
		
		BubbleSorter sorter = new BubbleSorter(a);
		sorter.sort();
		System.out.println(sorter);
		System.out.println(sorter.isSorted()  ?  "SORTED"  :  "NOT SORTED");
	}
}
